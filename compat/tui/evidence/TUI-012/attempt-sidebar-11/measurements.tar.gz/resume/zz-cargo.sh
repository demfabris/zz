#!/usr/bin/env bash
set -uo pipefail
CAP="${ZZ_CARGO_CAP:-4G}"
SWAP="${ZZ_CARGO_SWAP:-2G}"
JOBS="${ZZ_CARGO_JOBS:-2}"
S=$((RANDOM % 2))
ARGS=()
if [ "${1:-}" = fmt ]; then
  ARGS=("$@")
else
  for ARG in "$@"; do
    if [ "$ARG" = -- ]; then
      ARGS+=(--jobs "$JOBS")
      JOBS=""
    fi
    ARGS+=("$ARG")
  done
  [ -z "$JOBS" ] || ARGS+=(--jobs "$JOBS")
fi
exec systemd-run --user --scope -q \
  -p MemoryMax="$CAP" -p MemorySwapMax="$SWAP" \
  flock -w 3600 /tmp/zz-cargo-slot-$S.lock \
  cargo "${ARGS[@]}"
